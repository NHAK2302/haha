#include "Date.h"
#include "DynamicCString.h"
#include "Menu.h"
#include "Reader.h"
#include "User.h"
#include <stdio.h>
void main() {
	welcome();
}
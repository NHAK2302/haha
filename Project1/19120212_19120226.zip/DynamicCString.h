#pragma once
#include<iostream>
#include<memory.h>
#include<string.h>
const int LENGTH_MAX = 128;
void inputString(char* &s);

void copyString_statictodynamic(char* stat, char* &dyn);

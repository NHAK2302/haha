#pragma once
void welcome(FILE* f);
